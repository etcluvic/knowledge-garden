---
title: "Histories of artificial intelligence: a genealogy of power"
domain: Essential Contexts
tension: []
tags:
  - cited-in-introduction
  - annotation
  - topic-labour
type: annotation
created: 2026-05-14
---

# Histories of artificial intelligence: a genealogy of power

**Syed Mustafa Ali, Stephanie Dick, Sarah Dillon, Matthew L. Jones, Jonnie Penn; Richard Staley** (2023)

*BJHS Themes 8, 1-18, doi:10*


---

## Annotation

The work of these authors seeks to move beyond “conventional origin myths” of AI by contextualizing the academic historical approach within their interdisciplinary backgrounds. As a result, Ali et al. argue that histories of broader processes (like industrialization, colonialism, and social science) can represent the “genealogy” of AI, which is not identified as a specific object but as a grouping of diverse technologies under a loose banner, requiring an equally diverse approach. Although AI is the “flagship of the Information Age”, it was clearly conditioned by the “Management Age”, as these “genealogies” feature four common thematic threads of “hidden labour”, “encoded behaviour”, “disingenuous rhetoric” and “cognitive injustice”. AI is therefore not only situated within the history of computing, but the history of control, the product of the interacting formalist and empiricist views of “intelligence” within Cold War epistemology. In many ways, AI’s refinement of formal abstraction reinforces and impresses Western systems and structures, so these authors do not critique AI with the goal of improvement, but to clarify what AI “is”, “is not”, and perhaps “should not” be.

---


## 📖 Appears in Introduction

This annotation is cited in the following sections of the analytical introduction:

- [[Analytical Introduction]] — Fundamentals and Ideologies of AI
- [[Analytical Introduction]] — Taking Bearings: An Analytical Introduction to Artificial Intelligence in Knowledge Platforms and Open, Social Scholarship

*Navigate to [[Analytical Introduction]] for the complete overview.*

## Connections

**Domain**: [[Essential Contexts]] → Histories & Theories of AI

**Tensions**: *None detected*

**Key Concepts**: [[Diversity]] · [[Decolonization]] · [[Labour]]

**Methodologies**: `critical analysis`

**Stakeholders**: researchers, publishers

**Geographic Focus**: Global North

---

*Return to: [[Taking Bearings - Home]] | [[Essential Contexts]] | [[Concepts Glossary]]*

---

<details><summary>📎 Related Notes (2)</summary>

- [[Arora 2024 - Creative-data-justice-a-decolonial-and]] — *shared concepts: decolonization, labour, diversity | shared methodology: critical analysis*
- [[Mohamed 2020 - Decolonial-AI-Decolonial-Theory-as-Soci]] — *shared concepts: decolonization, labour, diversity*

</details>
