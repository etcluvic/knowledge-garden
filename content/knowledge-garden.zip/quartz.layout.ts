/**
 * Quartz Layout Configuration
 * 
 * Controls the UI components displayed on each page.
 * Optimized for knowledge garden navigation with graph view,
 * explorer, backlinks, and table of contents.
 */

import { PageLayout, SharedLayout } from "./quartz/cfg"
import * as Component from "./quartz/components"

// ── Shared across all pages ──────────────────────────────────────
export const sharedPageComponents: SharedLayout = {
  head: Component.Head(),
  header: [],
  afterBody: [],
  footer: Component.Footer({
    links: {
      "Source Document": "https://github.com",  // ← UPDATE with actual repo
      "Built with Quartz": "https://quartz.jzhao.xyz/",
    },
  }),
}

// ── Components shown BEFORE the main content ─────────────────────
export const beforeBody: PageLayout["beforeBody"] = [
  Component.Breadcrumbs(),
  Component.ArticleTitle(),
  Component.ContentMeta(),
  Component.TagList(),
]

// ── Left sidebar ─────────────────────────────────────────────────
export const left: PageLayout["left"] = [
  Component.PageTitle(),
  Component.MobileOnly(Component.Spacer()),
  Component.Search(),
  Component.Darkmode(),
  Component.DesktopOnly(
    Component.Explorer({
      title: "🗺️ Explorer",
      folderClickBehavior: "collapse",
      folderDefaultState: "collapsed",
      useSavedState: true,
      sortFn: (a, b) => {
        // Sort folders by their prefix number (00-Maps before 01-Concepts, etc.)
        if (a.file && b.file) return a.file.slug!.localeCompare(b.file.slug!)
        if (a.file && !b.file) return 1
        if (!a.file && b.file) return -1
        return a.name.localeCompare(b.name)
      },
      mapFn: (node) => {
        // Clean up folder display names (remove numeric prefixes)
        const prefixMap: Record<string, string> = {
          "00-Maps": "📍 Maps & Navigation",
          "01-Concepts": "💡 Concept Hubs",
          "02-Tensions": "⚡ Tensions",
          "03-Domains": "🌐 Domains",
          "04-Annotations": "📄 Annotations",
          "05-Indexes": "📑 Indexes",
        }
        if (!node.file && prefixMap[node.name]) {
          node.displayName = prefixMap[node.name]
        }
      },
    }),
  ),
]

// ── Right sidebar ────────────────────────────────────────────────
export const right: PageLayout["right"] = [
  Component.DesktopOnly(Component.TableOfContents()),
  Component.Graph({
    localGraph: {
      drag: true,
      zoom: true,
      depth: 2,               // Show 2 levels of connections
      scale: 1.2,
      repelForce: 0.5,
      centerForce: 0.3,
      linkDistance: 30,
      fontSize: 0.6,
      opacityScale: 1,
      removeTags: [],
      showTags: true,
    },
    globalGraph: {
      drag: true,
      zoom: true,
      depth: -1,              // Show all connections
      scale: 0.9,
      repelForce: 0.5,
      centerForce: 0.3,
      linkDistance: 30,
      fontSize: 0.5,
      opacityScale: 1,
      removeTags: [],
      showTags: true,
    },
  }),
  Component.Backlinks(),
]
