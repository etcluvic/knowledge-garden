/**
 * Quartz Configuration for: Taking Bearings — AI and Open Knowledge Production
 * 
 * SETUP INSTRUCTIONS:
 * 1. Install Quartz: `npx quartz create`
 * 2. Copy your knowledge-garden files into the Quartz `content/` directory
 *    (see README.md for detailed structure guidance)
 * 3. Replace the default quartz.config.ts with this file
 * 4. Run: `npx quartz build --serve` to preview locally
 * 5. Deploy to GitHub Pages, Netlify, Vercel, or Cloudflare Pages
 * 
 * Documentation: https://quartz.jzhao.xyz/
 */

import { QuartzConfig } from "./quartz/cfg"
import * as Plugin from "./quartz/plugins"

const config: QuartzConfig = {
  configuration: {
    // ── Site Metadata ──────────────────────────────────────────────
    pageTitle: "🧭 Taking Bearings",
    pageTitleSuffix: " — AI & Open Knowledge Production",
    enableSPA: true,
    enablePopovers: true,
    analytics: null,     // Add your analytics config here if desired
    locale: "en-US",
    baseUrl: "your-username.github.io/knowledge-garden",  // ← UPDATE THIS
    ignorePatterns: [
      "private",
      "templates",
      ".obsidian",
      "**/*.pdf",        // Exclude PDF copies of notes
      "**/*.docx",       // Exclude Word copies of notes
    ],
    defaultDateType: "created",
    theme: {
      fontOrigin: "googleFonts",
      cdnCaching: true,
      typography: {
        header: "Schibsted Grotesk",
        body: "Source Sans Pro",
        code: "IBM Plex Mono",
      },
      colors: {
        lightMode: {
          light: "#faf8f8",
          lightgray: "#e5e5e5",
          gray: "#b8b8b8",
          darkgray: "#4e4e4e",
          dark: "#2b2b2b",
          secondary: "#284b63",    // Deep blue — scholarly feel
          tertiary: "#84a59d",     // Sage green — knowledge garden
          highlight: "rgba(143, 159, 169, 0.15)",
          textHighlight: "#fff23688",
        },
        darkMode: {
          light: "#161618",
          lightgray: "#393639",
          gray: "#646464",
          darkgray: "#d4d4d4",
          dark: "#ebebec",
          secondary: "#7b97aa",
          tertiary: "#84a59d",
          highlight: "rgba(143, 159, 169, 0.15)",
          textHighlight: "#fff23688",
        },
      },
    },
  },

  plugins: {
    // ── Content Transformers ───────────────────────────────────────
    transformers: [
      Plugin.FrontMatter(),
      Plugin.CreatedModifiedDate({
        priority: ["frontmatter", "filesystem"],
      }),
      Plugin.SyntaxHighlighting(),
      Plugin.ObsidianFlavoredMarkdown({ enableInHtmlEmbed: false }),
      Plugin.GitHubFlavoredMarkdown(),
      Plugin.TableOfContents({
        maxDepth: 3,            // Show H2 and H3 in ToC
      }),
      Plugin.CrawlLinks({ markdownLinkResolution: "shortest" }),
      Plugin.Description(),
      Plugin.Latex({ renderEngine: "katex" }),
    ],

    // ── Filters ────────────────────────────────────────────────────
    filters: [
      Plugin.RemoveDrafts(),
    ],

    // ── Emitters (what gets generated) ─────────────────────────────
    emitters: [
      Plugin.AliasRedirects(),     // Makes aliases: [index] work for routing
      Plugin.ComponentResources(),
      Plugin.ContentPage(),
      Plugin.FolderPage(),         // Auto-generates folder listing pages
      Plugin.TagPage(),            // Auto-generates tag listing pages
      Plugin.ContentIndex({
        enableSiteMap: true,
        enableRSS: true,
        rssFullHtml: false,
        rssLimit: 50,
        includeEmptyFiles: false,
      }),
      Plugin.Assets(),
      Plugin.Static(),
      Plugin.NotFoundPage(),
    ],
  },
}

export default config
