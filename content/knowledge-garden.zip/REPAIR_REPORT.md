# ✅ Vault Repair Report — Complete

**Date:** May 15, 2026  
**Vault:** `/home/ubuntu/knowledge-garden/`  
**Source:** Clean PDF at `/home/ubuntu/Uploads/AI Scan - AI and Open Knowledge Production - reviewer feedback and cover update.pdf`

---

## Summary

| Metric | Value |
|--------|-------|
| Files checked | 258 |
| Files with real errors | 22 |
| Total real errors found | 32 |
| Errors corrected | 32 |
| Errors remaining | **0** |
| False positives filtered | 288 |
| YAML validation failures | 0 |

### Error Classification

Of the 284 initially reported errors, **288 were false positives** caused by proper nouns with internal capitals (ChatGPT, GenAI, arXiv, McCarthy, YouTube, TikTok, OpenAI, EleutherAI, ProCoT, etc.). These are correct text and required no modification.

The **32 real errors** fell into four categories:

---

## Fixes Applied

### 1. Missing Words (Double Space → Word Restored) — 17 fixes

| File | Before | After |
|------|--------|-------|
| Rapanta 2025 | `whose  and` | `whose knowledge counts and` |
| Rapanta 2025 | `evaluative  must` | `evaluative judgement must` |
| Checco 2021 | `review  operates` | `review judgement operates` |
| Fırıncı 2024 | `human  and` | `human judgement and` |
| Klein 2024 | `exploitative  practices` | `exploitative labour practices` |
| Kousha 2024 | `human  remains` | `human judgement remains` |
| Liang 2024 | `scientific  about` | `scientific judgement about` |
| Liang 2024 | `human  remains` | `human judgement remains` |
| Daniel Delmonaco 2024 | `human  to` | `human judgement to` |
| Sun 2025 | `of  in` | `of labour in` |
| Richter 2025 | `of  and` | `of labour and` |
| Chung 2025 | `on  markets` | `on labour markets` |
| Eloundou 2024 | `on  markets` | `on labor markets` |
| Yim 2025 | `pedagogy  AI` | `pedagogy approaches AI` |
| Bergstrom 2024 | `human  in` | `human judgement in` |
| Bostrom 2017 | `observing  the` | `observing the` (extra space only) |
| EXTRACTION_ERRORS_SUMMARY | `critical  required` | `critical judgement required` |

### 2. Truncated Sentences (Word + Space + Period → Complete) — 7 fixes

| File | Before | After |
|------|--------|-------|
| Sun 2025 | `evaluative .` | `evaluative judgement that gives scholarship its value.` |
| Ación 2023 | `how complicates .` | `how genAI complicates open knowledge.` |
| Gorwa 2020 | `displacing human .` | `displacing human judgement.` |
| Hosseini 2023 | `peer review .` | `peer review labour.` |
| Liang 2024 | `evaluative .` | `evaluative judgement.` |
| Pooley 2024 | `scholarly .` | `scholarly labour.` |
| Whalen 2023 | `situated .` | `situated labour.` |

### 3. Comma Space Gaps (Missing Word Before Comma) — 7 fixes

| File | Before | After |
|------|--------|-------|
| Checco 2021 | `substantive , ` | `substantive judgement, ` |
| Risam 2018 | `coding , ` | `coding labour, ` |
| Colbert-Lewis 2024 | `scholarly , ` | `scholarly labour, ` |
| Carroll 2021 | `be , ` | `be complementary, ` |
| Papagiannidis 2025 | `sensitive , ` | `sensitive judgement, ` |
| Al-kfairy 2024 | `Mousa , ` | `Mousa, ` |
| Complete Alphabetical List | `Report , ` | `Report, ` |

### 4. Concatenated Words — 1 fix

| File | Before | After |
|------|--------|-------|
| Prescott 2023 | `inequalitiesThe` | `inequalities. The` |

---

## Root Cause

The DOCX source file had systematic text corruption, predominantly dropping two words:
- **"judgement"** (British spelling) — 13 occurrences
- **"labour"** (British spelling) — 8 occurrences

These were likely caused by font encoding or conversion issues in the DOCX file.

---

## Integrity Verification

| Check | Result |
|-------|--------|
| YAML frontmatter valid | ✅ 256/256 files |
| Wikilinks preserved | ✅ 7,194 total |
| Analytical Introduction wikilinks | ✅ 140 links |
| Block IDs preserved | ✅ 111 IDs |
| See Also sections intact | ✅ 173/180 annotations |
| Tag sanitization | ✅ 0 issues |
| Windows-safe filenames | ✅ All clean |
| Folder structure | ✅ 6 folders intact |

### Folder Contents

| Folder | Files |
|--------|-------|
| 00-Maps | 5 |
| 01-Concepts | 55 |
| 02-Tensions | 4 |
| 03-Domains | 4 |
| 04-Annotations | 180 |
| 05-Indexes | 7 |

---

## Files Not Modified

The following files had reported errors that were all false positives (proper nouns) and required no changes:

- All concept hub files with ChatGPT/GenAI/arXiv references in titles
- All annotation files where only proper noun patterns were flagged
- The Analytical Introduction (7 reported errors were all ChatGPT/McCarthy proper nouns)
- README.md (camelCase in config examples like `baseUrl`, `enableSPA`)
