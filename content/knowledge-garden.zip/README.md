# 🧭 Taking Bearings — Knowledge Garden

**AI and Open Knowledge Production**: A Quartz-published knowledge garden built from 180 research sources.

---

## 📁 Directory Structure

```
knowledge-garden/               ← This is your Quartz /content directory
├── index.md                    ← Landing page (root-level for Quartz)
├── quartz.config.ts            ← Quartz site configuration (copy to Quartz root)
├── quartz.layout.ts            ← Quartz layout configuration (copy to Quartz root)
├── README.md                   ← This file
│
├── 00-Maps/                    ← Navigation & overview documents
│   ├── Taking Bearings - Home.md   (canonical home page, aliased as "index")
│   ├── Analytical Introduction.md  (main analytical essay)
│   ├── Conceptual Map.md
│   ├── Concepts Glossary.md
│   └── Recommendations.md
│
├── 01-Concepts/                ← 55 concept hub notes
│   └── Epistemic Authority.md, Data Sovereignty.md, ...
│
├── 02-Tensions/                ← 4 cross-cutting tension notes
│   └── Openness vs Enclosure.md, ...
│
├── 03-Domains/                 ← 4 domain overview notes
│   └── Essential Contexts.md, AI and Scholarship.md, ...
│
├── 04-Annotations/             ← 180 individual research annotations
│   └── Author Year - Title.md, ...
│
└── 05-Indexes/                 ← Navigation indexes
    └── Index by Domain.md, Index by Author.md, Citation Index.md, ...
```

---

## 🚀 Setting Up with Quartz

### Prerequisites

- [Node.js](https://nodejs.org/) v18.14+
- [Git](https://git-scm.com/)
- [npm](https://www.npmjs.com/) (comes with Node.js)

### Step 1: Install Quartz

```bash
git clone https://github.com/jackyzha0/quartz.git
cd quartz
npm i
```

### Step 2: Add Your Content

**The knowledge-garden contents go directly into Quartz's `content/` directory.** This is the recommended approach:

```bash
# Remove the default content
rm -rf content/*

# Copy knowledge garden files into content/
cp -r /path/to/knowledge-garden/* content/

# IMPORTANT: Do NOT copy these into content/ — they go to the Quartz root:
cp content/quartz.config.ts ./quartz.config.ts
cp content/quartz.layout.ts ./quartz.layout.ts
rm content/quartz.config.ts content/quartz.layout.ts
rm content/README.md
```

Your Quartz directory should look like:

```
quartz/                         ← Quartz project root
├── quartz.config.ts            ← Site configuration (from this repo)
├── quartz.layout.ts            ← Layout configuration (from this repo)
├── content/                    ← YOUR KNOWLEDGE GARDEN GOES HERE
│   ├── index.md                ← Landing page (Quartz serves this at /)
│   ├── 00-Maps/
│   ├── 01-Concepts/
│   ├── 02-Tensions/
│   ├── 03-Domains/
│   ├── 04-Annotations/
│   └── 05-Indexes/
├── quartz/                     ← Quartz source code (don't modify)
└── package.json
```

### Step 3: Configure

Edit `quartz.config.ts` at the Quartz root:

1. **Update `baseUrl`** — Set to your deployment URL:
   ```ts
   baseUrl: "your-username.github.io/knowledge-garden"
   ```

2. **Update footer links** in `quartz.layout.ts` if desired.

### Step 4: Preview Locally

```bash
npx quartz build --serve
# Opens at http://localhost:8080
```

### Step 5: Deploy

#### GitHub Pages (recommended)

```bash
npx quartz sync --no-pull
```

Then enable GitHub Pages in your repo settings (Settings → Pages → Source: Deploy from branch `gh-pages`).

#### Other platforms

See the [Quartz hosting docs](https://quartz.jzhao.xyz/hosting) for Netlify, Vercel, and Cloudflare Pages instructions.

---

## 🏠 How the Home Page Works

Quartz looks for `content/index.md` as the default landing page. This garden provides **two copies** of the home page for maximum compatibility:

| File | Purpose |
|------|---------|
| `index.md` (root) | **Primary**: Quartz serves this at `/` automatically |
| `00-Maps/Taking Bearings - Home.md` | **Canonical**: Has `aliases: [index]` in frontmatter; keeps the note in its logical location for Obsidian use |

**If you edit the home page**, update both files (or delete `index.md` and rely solely on the alias — this works in most Quartz versions but the root `index.md` approach is more reliable).

---

## 🔄 Syncing with Obsidian

This knowledge garden works in both Obsidian and Quartz:

1. **Open the `knowledge-garden/` folder as an Obsidian vault** for local editing
2. **Sync changes to the Quartz `content/` directory**:
   ```bash
   # Option A: Symlink (recommended for local dev)
   ln -s /path/to/knowledge-garden /path/to/quartz/content
   
   # Option B: Copy on change
   rsync -av --delete \
     --exclude='.obsidian' \
     --exclude='*.pdf' \
     --exclude='*.docx' \
     /path/to/knowledge-garden/ /path/to/quartz/content/
   ```
3. **Rebuild**: `npx quartz build --serve`

---

## ⚙️ Key Quartz Settings Explained

| Setting | Value | Why |
|---------|-------|-----|
| `enableSPA` | `true` | Smooth page transitions without full reloads |
| `enablePopovers` | `true` | Hover previews on wikilinks |
| `ignorePatterns` | `.obsidian, *.pdf, *.docx` | Exclude Obsidian config and binary files |
| `Explorer` | Collapsed folders, renamed | Clean sidebar with emoji folder names |
| `Graph` | depth: 2 (local), full (global) | Useful local context; explorable global view |
| `Backlinks` | Enabled | See what links to the current page |
| `TableOfContents` | maxDepth: 3 | Show H2/H3 in right sidebar |
| `FolderPage` | Enabled | Auto-generates index pages for each folder |
| `TagPage` | Enabled | Auto-generates pages for each tag |

---

## 📝 Notes

- **PDF/DOCX files**: The garden may contain auto-generated PDF and Word copies of some notes. These are excluded from Quartz via `ignorePatterns`.
- **`.obsidian/` folder**: Contains Obsidian-specific config. Excluded from Quartz publishing.
- **Wikilinks**: Quartz natively supports `[[wikilinks]]` via the `ObsidianFlavoredMarkdown` plugin.
- **Tags**: All notes have YAML frontmatter tags. Quartz auto-generates tag pages.
- **Graph view**: The local graph shows 2 levels of connections; the global graph shows everything.

---

## 📄 License

Content derived from the research scan *"Taking Bearings: AI and Open Knowledge Production"*.
